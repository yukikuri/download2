/////////////////////////////////////////////////////////////////////////////////////
// local
var 
 $$=document.getElementById
,$c=document.createElement
,$t=document.createTextNode
;
/////////////////////////////////////////////////////////////////////////////////////
// common
function removeChildren(elem){
	while(elem.firstChild)elem.removeChild(elem.firstChild);
}
function replaceChild(elem,child){
	removeChildren(elem);
	elem.appendChild(child);
}
function replaceChildren(elem,children){
	removeChildren(elem);
	for(i=0;i<children.length;++i)elem.appendChild(children[i]);
}
function sn(s)
{
	s=s.replace('<',"&lt;");
	s=s.replace('>',"&gt;");
	return s;
}
